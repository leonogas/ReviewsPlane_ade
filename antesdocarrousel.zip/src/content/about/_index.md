---
title: "Reviews Plane was started in August of 2023."
meta_title: "About"
description: "this is meta description"
image: "/images/avatar.png"
draft: false
---



The purpose of the website is to provide meaningful recommendations of gift items for that special loved one on that special ocassion. We review items from multiple sites and categorise by relation, by ocassion, etc.

