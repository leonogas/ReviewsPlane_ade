---
title: "Affiliate Disclaimer"
meta_title: "Affiliate Disclaimer"
description: "this is meta description"
draft: false
---

Some of the links on this website are affliate links. This means
thay if you choose to pruchase through those links, we may receive a
commission.

This does not incur any cost to you, in fact in some cases you will
receive a discount.
There commissions help support the content for our website. All the
products are thoroughly tested before publishing. We are an
idenpendently owned and the opinions expressed are our own.

Thank you.

Email: "support@reviewsplane.com" for any inquiries.
